﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Communication
{
    static class MessageSerializer
    {
        public static void Serializer(IMessage msg, ref byte[] buffer)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(msg.GetType());
            using (StringWriter textWriter = new StringWriter())
            {
                xmlSerializer.Serialize(textWriter, msg);
                Console.WriteLine(textWriter.ToString());
                buffer = System.Text.UTF8Encoding.UTF8.GetBytes(textWriter.ToString());
            }
        }
        public static void Deserializer(ref IMessage msg, byte[] buffer)
        {
            String xml = System.Text.UTF8Encoding.UTF8.GetString(buffer);
            xml = xml.Remove(xml.IndexOf('\0'));
            Console.WriteLine(xml);
            XmlSerializer xmlSerializer = new XmlSerializer(msg.GetType());

            using (XmlReader reader = XmlReader.Create(new StringReader(xml)))
            {
                reader.MoveToContent();
                msg = (IMessage)xmlSerializer.Deserialize(reader);
            }
        }
    }
}
