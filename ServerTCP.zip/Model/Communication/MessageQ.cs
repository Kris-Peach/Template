﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Communication
{
    public class MessageQ:IMessage
    {
       public int Action;
       public double a;
       public double b;
       public double c;
    }
}
