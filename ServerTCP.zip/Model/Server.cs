﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using $safeprojectname$.Properties;
using Communication;

namespace $safeprojectname$
{
    class Server
    {

        private class ConnectionInfo //Вложеный класс который содержит информацию о соединении
        {
            public Socket Socket; //Сокет соединения
            public Thread Thread;//Поток соединения
            public const int BufferSize = 1024;//Размер буфера 
            public byte[] buffer = new byte[BufferSize];//Буфер
        }

        public static ManualResetEvent allDone;
        private List<ConnectionInfo> connections;

       // String IP = "192.168.137.156";
       //int MaxClient = 100;
       //int Port = 11000;
        public Server()
        {
             allDone = new ManualResetEvent(false); //Уведомляет один или более ожидающих потоков о том, что произошло событие.
             connections= new List<ConnectionInfo>();//
        }
        public void StartListening()
        {
            var settings = $safeprojectname$.Properties.Settings.Default;
            IPHostEntry ipHost = Dns.GetHostEntry(settings.IP);// Разрешает имя узла или IP - адрес в экземпляр
            IPAddress ipAddr = ipHost.AddressList[0];//Получает первый ip связанный с этим узлом
            IPEndPoint ipEndPoint = new IPEndPoint(ipAddr, settings.Port); // Представляет сетевую конечную точка в виде IP-адреса и номера порта

            Socket listener = new Socket(ipAddr.AddressFamily,
                SocketType.Stream, ProtocolType.Tcp);//Инициализирует новый экземпляр класса Socket, используя заданные семейство адресов, тип сокета и протокол.

            try
            {
                listener.Bind(ipEndPoint); //Привязывание сокета к прослушиваемому порту
                listener.Listen(settings.MaxClient); //Устанавливает объект Socket в состояние прослушивания. Максимальное кол-во соединений 100

                while (true)
                {
                    allDone.Reset(); //Задает несигнальное состояние события, вызывая блокирование потоков.

                    // Start an asynchronous socket to listen for connections.
                    Console.WriteLine("Waiting for a connection...");
                    listener.BeginAccept(
                        new AsyncCallback(AcceptCallback),
                        listener);

                    // Дождитесь соединения, прежде чем продолжить.
                    allDone.WaitOne();
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

            Console.WriteLine("\nPress ENTER to continue...");
            Console.Read();
        }
        public void AcceptCallback(IAsyncResult ar)
        {
            // Signal the main thread to continue.
            allDone.Set();

            // Get the socket that handles the client request.
            Socket listener = (Socket)ar.AsyncState;
            Socket handler = listener.EndAccept(ar);
            ConnectionInfo connection = new ConnectionInfo();
            connection.Socket = handler;

            connection.Thread = new Thread(ProcessConnection);
            connection.Thread.IsBackground = true;
            connection.Thread.Start(connection);
            lock (connections) connections.Add(connection);
        }
        private void ProcessConnection(object state)
        {
            ConnectionInfo connection = (ConnectionInfo)state;
            try
            {
                while (true)
                {
                    int bytesRead = connection.Socket.Receive(
                    connection.buffer);

                    if (bytesRead > 0)
                    {
                        MessageQ msg = new MessageQ();
                        IMessage m = msg;
                        MessageSerializer.Deserializer(ref m, connection.buffer);
                        msg = (MessageQ)m;
                        Console.WriteLine("Получено сообщение");
                        MessageA answer = ProcessingMsg(msg);
                        MessageSerializer.Serializer(answer, ref connection.buffer);
                        connection.Socket.Send(connection.buffer);

                    }
                    else if (bytesRead == 0) return;
                }
            }
            catch (SocketException exc)
            {
                Console.WriteLine("Socket exception: " +
                    exc.SocketErrorCode);
            }
            catch (Exception exc)
            {
                Console.WriteLine("Exception: " + exc);
            }
            finally
            {
                connection.Socket.Close();
                lock (connections) connections.Remove(
                    connection);
            }
        }

        private MessageA ProcessingMsg(MessageQ msg)
        {
            //Code

            throw new NotImplementedException();
        }
    }
}                    
