﻿using System;
using System.Collections.Generic;
using System.IO.Pipes;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Communication;
namespace $safeprojectname$
{
    class Server
    {
        private class ConnectionInfoPipe //Вложеный класс который содержит информацию о соединении
        {
            public NamedPipeServerStream serverPipe; //Канал соединения
            //public NamedPipeServerStream serverPipeOut; //Канал соединения
            public Thread Thread;//Поток соединения
            public const int BufferSize = 1024;//Размер буфера 
            public byte[] buffer = new byte[BufferSize];//Буфер
        }

        private List<ConnectionInfoPipe> connectionsPipe;//
       
        //Функция которая настраивает соединение, по которому будет слушать 
        public void StartListeningPipe()
        {
            var settings = $safeprojectname$.Properties.Settings.Default;
            while (true)
            {
                NamedPipeServerStream pipeServer = new NamedPipeServerStream(settings.NamePipe, PipeDirection.InOut, settings.MaxClient);
                Console.Write("Waiting for client connection...");
                pipeServer.WaitForConnection();
                Console.WriteLine("Client connected.");
                ConnectionInfoPipe connection = new ConnectionInfoPipe();
                connection.serverPipe = pipeServer;
                connection.Thread = new Thread(ProcessConnectionPipe);
                connection.Thread.IsBackground = true;
                connection.Thread.Start(connection);
                lock (connectionsPipe) connectionsPipe.Add(connection);
            }
            Console.WriteLine("\nPress ENTER to continue...");
            Console.Read();
        }
        public void ProcessConnectionPipe(Object status)
        {
            ConnectionInfoPipe connection = (ConnectionInfoPipe)status;
            int max = connection.buffer.Length;

            Console.WriteLine("Есть соединение");
            try
            {
                int bytesRead = connection.serverPipe.Read(connection.buffer, 0, max);
                if (bytesRead > 0)
                {
                    MessageQ msg = new MessageQ();
                    IMessage m = msg;
                    MessageSerializer.Deserializer(ref m, connection.buffer);
                    msg = (MessageQ)m;
                    Console.WriteLine("Получено сообщение");
                    MessageA answer = ProcessingMsg(msg);
                    MessageSerializer.Serializer(answer, ref connection.buffer);
                    connection.serverPipe.Write(connection.buffer, 0, max);
                }
                else if (bytesRead == 0) return;
            }
            catch (Exception exc)
            {
                Console.WriteLine("Exception: " + exc);
            }
            finally
            {
                connection.serverPipe.Close();
                lock (connectionsPipe) connectionsPipe.Remove(connection);
            }
        }

        private MessageA ProcessingMsg(MessageQ msg)
        {


            //Code


            throw new NotImplementedException();
        }
    }
}
