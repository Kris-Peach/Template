﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    class Message : IMessage
    {
        public Message(String content)
        {
            Content = content;
        }
        public String Content
        {
            get;
            set;
        }
    }
}
