﻿using System;

namespace $safeprojectname$
{
        public class MessageReceivedEventArgs : EventArgs
        {
            public MessageReceivedEventArgs(IMessage message)
            {
                Message = message;
            }

            public IMessage Message
            {
                get;
                private set;
            }
        }
}