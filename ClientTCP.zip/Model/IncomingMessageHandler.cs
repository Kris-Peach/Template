﻿using System;
namespace $safeprojectname$
{
    class IncomingMessageHandler
    {
        public void ProcessMessage(String message)
        {

        }
    }
}