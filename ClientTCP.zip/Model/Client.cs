﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using Communication;
namespace $safeprojectname$
{
        class Client : IDisposable
        {
            private readonly IncomingMessageHandler mMessageHandler;
            private readonly StreamReader mReader;
            private readonly StreamWriter mWriter;
            private readonly TcpClient mClient;

            public event EventHandler<MessageReceivedEventArgs> OnMessageReceived;

            public Client()
            {
                var settings = Properties.Settings.Default;
                mClient = new TcpClient(settings.Ip, settings.Port);
                mMessageHandler = new IncomingMessageHandler();
                mReader = new StreamReader(mClient.GetStream());
                mWriter = new StreamWriter(mClient.GetStream())
                {
                    AutoFlush = true
                };
            }
            public MessageA StartReceive()
            {
                MessageA ans = new MessageA();
                try
                {
                    char[] buffer = new char[1024];
                    mReader.Read(buffer, 0, 1024);
                    IMessage m = ans;
                    MessageSerializer.Deserializer(ref m, System.Text.UTF8Encoding.UTF8.GetBytes(buffer));
                    ans = (MessageA)m;
                    return ans;
                }
                catch (SocketException e)
                {
                    Console.WriteLine(e.Message);
                    return ans;
                }
            }

            public void Send(MessageQ message)
            {
                try
                {
                    byte[] buffer = new byte[1024];
                    MessageSerializer.Serializer(message, ref buffer);
                    mWriter.WriteLine(System.Text.UTF8Encoding.UTF8.GetString(buffer));

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }


            public void Dispose()
            {
                mClient.Close();
                mReader.Dispose();
                mWriter.Dispose();
            }
        }
}

