﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using $safeprojectname$.Properties;

namespace $safeprojectname$
{
    class Program
    {
        static void Main(string[] args)
        {
            var settings = $safeprojectname$.Properties.Settings.Default;
            TcpClient TCPclient = new TcpClient(settings.Ip, settings.Port);
            var client = new Client(TCPclient);
            Console.ReadKey();
        }
    }
}
