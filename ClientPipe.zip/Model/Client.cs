﻿using System;
using System.Collections.Generic;
using System.IO.Pipes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Communication;

namespace $safeprojectname$
{
    class Client
    {
        private System.IO.Pipes.NamedPipeClientStream pipeClient;
        private const int BufferSize = 1024;//Размер буфера 
        private byte[] buffer = new byte[BufferSize];//Буфер
        public Client()
        {
            var settings = Properties.Settings.Default;
            pipeClient = new NamedPipeClientStream(".", settings.NamePipe, PipeDirection.InOut);
        }

        public MessageA AskServer(MessageQ msg)
        {
            MessageA ans = new MessageA();
            try
            {
                pipeClient = new NamedPipeClientStream(".", "testpipe", PipeDirection.InOut);
                pipeClient.Connect();
                MessageSerializer.Serializer(msg, ref buffer);
                pipeClient.Write(buffer, 0, BufferSize);

                int bytesRec = pipeClient.Read(buffer, 0, BufferSize);//получили ответ от сервера
                IMessage m = ans;
                MessageSerializer.Deserializer(ref m, buffer);
                ans = (MessageA)m;
                return ans;
                //return buffer;
            }
            catch (Exception exc)
            {
                return ans;   
            }
            finally
            {
                pipeClient.Close();
            }
        }
    }
}
